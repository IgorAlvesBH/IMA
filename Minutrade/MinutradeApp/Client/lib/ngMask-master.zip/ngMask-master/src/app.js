(function() {
  'use strict';
  angular.module('ngMask', []);
})();