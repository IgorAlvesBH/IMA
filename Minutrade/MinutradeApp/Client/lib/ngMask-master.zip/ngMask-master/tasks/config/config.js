module.exports = {
  app: 'src',
  dist: 'dist'
}