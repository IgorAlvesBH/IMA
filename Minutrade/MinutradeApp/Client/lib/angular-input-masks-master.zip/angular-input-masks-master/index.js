'use strict';

var moduleName = require('./src/angular-input-masks.js');

module.exports = moduleName;
