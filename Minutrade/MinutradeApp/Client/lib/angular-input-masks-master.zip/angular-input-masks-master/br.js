'use strict';

module.exports = require('./src/angular-input-masks.br');
